VLEBook Print Bridge 1.0 (for VLEBook 3.4)

1. Unzip this folder anywhere (for example Documents\VLEBook Print Bridge).
2. Double-click "Start VLEBook Print Bridge.cmd". If Windows shows "Windows protected your PC", click More info -> Run anyway (the files are plain text you can read in Notepad).
3. Keep the black window open. In VLEBook open PDF & Image Studio -> Print & printers -> Connect Print Bridge, and type the 6-digit code shown in the window.

The Bridge works only on this computer (127.0.0.1), only for the VLEBook web address, and only after pairing. It does not install anything and needs no administrator rights. To remove it, close the window and delete the folder (and %APPDATA%\VLEBookPrintBridge).

Printer features shown in VLEBook are exactly what the Windows driver reports. Printing on your PVC / card printer is to be checked by you after going live.
