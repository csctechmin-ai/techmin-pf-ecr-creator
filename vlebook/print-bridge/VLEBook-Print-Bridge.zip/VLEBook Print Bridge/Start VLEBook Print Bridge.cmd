@echo off
rem VLEBook Print Bridge - lets VLEBook list this computer's printers and print to them directly.
rem Keep the window that opens; close it to stop the Bridge.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VLEBook-Print-Bridge.ps1"
if errorlevel 1 pause
