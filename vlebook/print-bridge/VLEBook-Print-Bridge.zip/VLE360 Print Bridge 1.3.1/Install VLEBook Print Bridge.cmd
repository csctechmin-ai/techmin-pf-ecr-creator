@echo off
rem VLEBook Print Bridge - installer for this Windows user (no administrator rights needed).
rem Copies the Bridge to your user folder, adds it to Windows start-up and the Start menu, and starts it in the background.
rem If a Bridge is already installed or running, it first tells you its version and asks before replacing it.
setlocal
set "DEST=%LOCALAPPDATA%\VLEBook Print Bridge"
set "KIND="
set "OLDV="
set "NEWV="
for /f "usebackq tokens=1,2,3" %%a in (`powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VLEBook-Print-Bridge.ps1" -FindOld`) do (
  set "KIND=%%a"
  set "OLDV=%%b"
  set "NEWV=%%c"
)
if /i "%KIND%"=="older" goto :older
if /i "%KIND%"=="same" goto :same
if /i "%KIND%"=="newer" goto :newer
goto :install

:older
echo.
echo  An older version of the VLEBook Print Bridge (%OLDV%) was found on this computer.
echo  The new version is %NEWV%.
echo.
choice /C YN /M " Uninstall the old version and install the new one"
if errorlevel 2 goto :cancel
goto :removeold

:same
echo.
echo  VLEBook Print Bridge %OLDV% is already installed on this computer.
echo.
choice /C YN /M " Install it again"
if errorlevel 2 goto :cancel
goto :removeold

:newer
echo.
echo  A NEWER VLEBook Print Bridge (%OLDV%) is already installed. This download is version %NEWV%.
echo  Keep the newer one unless Techmin support asked you to go back.
echo.
choice /C YN /M " Replace the newer version with %NEWV%"
if errorlevel 2 goto :cancel
goto :removeold

:removeold
echo.
echo  Removing the old version (your printer connection settings are kept)...
if exist "%DEST%\VLEBook-Print-Bridge.ps1" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DEST%\VLEBook-Print-Bridge.ps1" -Uninstall
goto :install

:install
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0VLEBook-Print-Bridge.ps1" "%DEST%\" >nul
copy /Y "%~dp0VLEBook Print Bridge.vbs" "%DEST%\" >nul
copy /Y "%~dp0Uninstall VLEBook Print Bridge.cmd" "%DEST%\" >nul
copy /Y "%~dp0Start VLEBook Print Bridge (window).cmd" "%DEST%\" >nul
copy /Y "%~dp0README.txt" "%DEST%\" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DEST%\VLEBook-Print-Bridge.ps1" -Install
if errorlevel 1 (
  echo.
  echo The Print Bridge could not be installed. See README.txt.
  pause
  exit /b 1
)
start "" wscript.exe "%DEST%\VLEBook Print Bridge.vbs"
echo.
echo  VLEBook Print Bridge is installed and running.
echo  Its icon is in the notification area (click ^^ next to the clock).
echo  It starts with Windows and connects to VLEBook by itself.
echo.
echo  This window closes in 8 seconds.
timeout /t 8 >nul
exit /b 0

:cancel
echo.
echo  Nothing was changed. The Print Bridge already on this computer keeps working.
echo.
pause
exit /b 0
