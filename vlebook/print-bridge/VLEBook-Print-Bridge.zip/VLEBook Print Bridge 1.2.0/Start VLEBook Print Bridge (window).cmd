@echo off
rem VLEBook Print Bridge in a visible window (for troubleshooting). Normally use the installer instead.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VLEBook-Print-Bridge.ps1" -Console
if errorlevel 1 pause
