<#
  VLEBook Print Bridge  (version 1.2.0, for VLEBook 3.4)
  ----------------------------------------------------
  A small helper that runs only on this Windows computer, so that VLEBook (in Chrome or Edge) can:
    * list the printers installed in Windows and read what each driver reports (paper sizes, resolutions,
      colour, duplex, trays, default printer, online/offline);
    * send print-ready pages straight to the printer you choose, at exact physical size, with the copies,
      duplex, colour and paper settings the driver accepts.

  Safety
    * Listens only on 127.0.0.1 (this computer). Other computers on the network cannot reach it.
    * Accepts requests only from the VLEBook web address (and a local test address).
    * A browser must be paired once: the Bridge shows a 6-digit code in this window and you type it in VLEBook.
    * It never runs commands sent to it, never reads or writes your files, and keeps no copy of what is printed.
    * The log in this window shows job numbers and printer names only, never names or document contents.

  Install: double-click "Install VLEBook Print Bridge.cmd" once. It runs hidden with an icon in the notification area
  (right-click it for status, log, Start with Windows and Quit), starts with Windows and connects to VLEBook by itself.
  Troubleshooting: "Start VLEBook Print Bridge (window).cmd" runs it in a visible window instead.
  Needs Windows 10 or 11 with Windows PowerShell 5.1 (built in). No installation and no administrator rights.
  Free software by Techmin Wealth Partners. Provided "as is" - see the VLEBook terms.
#>

param([int]$Port = 47123, [switch]$Install, [switch]$Uninstall, [switch]$Console)
$ErrorActionPreference = 'Stop'
$Version = '1.2.0'
# The VLEBook web address that is connected automatically (no pairing code). Any other allowed address must pair with a code.
$AutoPairOrigins = @('https://tools.complypro.co.in')
$AppUrl = 'https://tools.complypro.co.in/vlebook/'
$AllowedOrigins = @('https://tools.complypro.co.in', 'http://localhost:4150', 'http://127.0.0.1:4150', 'http://localhost:4173', 'http://127.0.0.1:4173')
$MaxBody = 80MB

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web

$DataDir = Join-Path $env:APPDATA 'VLEBookPrintBridge'
if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir | Out-Null }
$TokenFile = Join-Path $DataDir 'paired-browsers.json'
$Tokens = @{}
if (Test-Path $TokenFile) { try { (Get-Content $TokenFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $Tokens[$_.Name] = $_.Value } } catch { $Tokens = @{} } }
$PairCode = $null
$PairUntil = Get-Date
$Jobs = @{}

$LogFile = Join-Path $DataDir 'bridge.log'
function Log($t) {
  $line = "{0:yyyy-MM-dd HH:mm:ss}  {1}" -f (Get-Date), $t
  if ($Console) { Write-Host $line }
  try {
    if ((Test-Path $LogFile) -and (Get-Item $LogFile).Length -gt 1MB) { Move-Item -Force $LogFile ($LogFile + '.old') }
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
  } catch {}
}
function NewCode { (Get-Random -Minimum 100000 -Maximum 999999).ToString() }
function NewToken { $b = New-Object byte[] 32; [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_') }
# Windows PowerShell 5.1's ConvertFrom-Json refuses text over about 2 MB, and a print job with page images is larger.
# The .NET JavaScriptSerializer (part of Windows) reads it with no such limit; ConvertFrom-Json is the fallback.
$script:JsonReader = $null
try {
  Add-Type -AssemblyName System.Web.Extensions -ErrorAction Stop
  $script:JsonReader = New-Object System.Web.Script.Serialization.JavaScriptSerializer
  $script:JsonReader.MaxJsonLength = [int]::MaxValue
  $script:JsonReader.RecursionLimit = 100
} catch { $script:JsonReader = $null }
function ParseJson([string]$text) {
  if ($script:JsonReader) { return $script:JsonReader.DeserializeObject($text) }
  return ($text | ConvertFrom-Json)
}

function SaveTokens { ($Tokens | ConvertTo-Json -Compress) | Set-Content -Path $TokenFile -Encoding UTF8 }

# ------------------------------------------------------------------ printers

function Get-PrinterList {
  $default = $null
  try { $default = (New-Object System.Drawing.Printing.PrinterSettings).PrinterName } catch {}
  $wmi = @{}
  try { Get-CimInstance Win32_Printer | ForEach-Object { $wmi[$_.Name] = $_ } } catch {}
  $out = @()
  foreach ($name in [System.Drawing.Printing.PrinterSettings]::InstalledPrinters) {
    $w = $wmi[$name]
    $status = 'Unknown'
    if ($w) {
      if ($w.WorkOffline) { $status = 'Offline' }
      elseif ($w.PrinterStatus -eq 3) { $status = 'Ready' }
      elseif ($w.PrinterStatus -eq 4) { $status = 'Printing' }
      elseif ($w.PrinterStatus -eq 5) { $status = 'Warming up' }
      elseif ($w.PrinterStatus -eq 7) { $status = 'Offline' }
      elseif ($w.PrinterStatus -eq 1 -or $w.PrinterStatus -eq 2) { $status = 'Other / unknown' }
    }
    $port = if ($w) { [string]$w.PortName } else { '' }
    $conn = 'Local'
    if ($w -and $w.Network) { $conn = 'Network' }
    elseif ($port -match '^USB') { $conn = 'USB' }
    elseif ($port -match '^(IP_|WSD|TCP|http)') { $conn = 'Network' }
    elseif ($port -match '^(PORTPROMPT|FILE|nul|XPS|PDF)' -or ([string]$w.DriverName) -match 'PDF|XPS|OneNote|Fax') { $conn = 'Virtual' }
    $out += [ordered]@{
      name = $name
      driver = if ($w) { [string]$w.DriverName } else { '' }
      port = $port
      connection = $conn
      shared = if ($w) { [bool]$w.Shared } else { $false }
      isDefault = ($name -eq $default)
      status = $status
      location = if ($w) { [string]$w.Location } else { '' }
    }
  }
  return ,$out
}

# Maker adapters: which family a printer belongs to and what VLEBook can do with it through Windows.
# No maker SDK is bundled or required; features that need one (encoding, ribbon level) stay in the maker's software.
$Adapters = @(
  @{ id = 'EVOLIS'; maker = 'Evolis'; match = 'evolis|primacy|zenius|badgy' },
  @{ id = 'ZEBRA'; maker = 'Zebra'; match = 'zebra|zxp|zc100|zc300' },
  @{ id = 'FARGO'; maker = 'HID Fargo'; match = 'fargo|dtc\d|hdp\d' },
  @{ id = 'MAGICARD'; maker = 'Magicard'; match = 'magicard|enduro|rio pro|pronto' },
  @{ id = 'IDP'; maker = 'IDP'; match = '\bidp\b|smart[- ]?(30|31|51)' }
)
function Get-Adapter($name, $driver) {
  foreach ($a in $Adapters) { if (("$name $driver") -match $a.match) { return [ordered]@{ id = $a.id; maker = $a.maker; route = 'Windows driver'; can = @('exact-size pages', 'two-sided when the driver reports it', 'open the maker settings window', 'Windows queue and status'); needsMakerSoftware = @('magnetic stripe / chip encoding', 'ribbon and card levels', 'cleaning routines') } } }
  return [ordered]@{ id = 'GENERIC'; maker = ''; route = 'Windows driver'; can = @('exact-size pages', 'paper, tray, colour, two-sided and resolution as the driver reports', 'open the printer settings window', 'Windows queue and status'); needsMakerSoftware = @() }
}

function Get-PrinterCaps($name) {
  $ps = New-Object System.Drawing.Printing.PrinterSettings
  $ps.PrinterName = $name
  if (-not $ps.IsValid) { throw "Printer not found: $name" }
  $papers = @()
  foreach ($p in $ps.PaperSizes) { $papers += [ordered]@{ name = $p.PaperName; kind = [string]$p.Kind; widthMm = [math]::Round($p.Width * 0.254, 1); heightMm = [math]::Round($p.Height * 0.254, 1) } }
  $res = @()
  foreach ($r in $ps.PrinterResolutions) { if ($r.X -gt 0) { $res += [ordered]@{ x = $r.X; y = $r.Y; kind = [string]$r.Kind } } else { $res += [ordered]@{ x = 0; y = 0; kind = [string]$r.Kind } } }
  $src = @()
  foreach ($s in $ps.PaperSources) { $src += [ordered]@{ name = $s.SourceName; kind = [string]$s.Kind } }
  $dp = $ps.DefaultPageSettings
  $driverVersion = ''
  $drvName = ''
  try { $drvName = [string](Get-CimInstance Win32_Printer -Filter ("Name='" + $name.Replace("'", "''").Replace('\', '\\') + "'")).DriverName } catch {}
  $mfr = ''
  try { $d = Get-PrinterDriver -Name $drvName -ErrorAction Stop; $driverVersion = [string]$d.DriverVersion; $mfr = [string]$d.Manufacturer } catch {}
  $adapter = Get-Adapter $name $drvName
  return [ordered]@{
    name = $name
    manufacturer = $mfr
    driverVersion = $driverVersion
    canDuplex = [bool]$ps.CanDuplex
    supportsColor = [bool]$ps.SupportsColor
    maximumCopies = [int]$ps.MaximumCopies
    landscapeAngle = [int]$ps.LandscapeAngle
    isPlotter = [bool]$ps.IsPlotter
    papers = $papers
    resolutions = $res
    sources = $src
    defaultPaper = if ($dp.PaperSize) { $dp.PaperSize.PaperName } else { '' }
    defaultLandscape = [bool]$dp.Landscape
    hardMarginMm = [ordered]@{ x = [math]::Round($dp.HardMarginX * 0.254, 1); y = [math]::Round($dp.HardMarginY * 0.254, 1) }
    printableAreaMm = [ordered]@{ w = [math]::Round($dp.PrintableArea.Width * 0.254, 1); h = [math]::Round($dp.PrintableArea.Height * 0.254, 1) }
    adapter = $adapter
    note = 'As reported by the Windows driver. A feature the driver does not report is shown as not available.'
  }
}

# ------------------------------------------------------------------ printing

function Invoke-Print($job) {
  $name = [string]$job.printer
  $ps = New-Object System.Drawing.Printing.PrinterSettings
  $ps.PrinterName = $name
  if (-not $ps.IsValid) { throw "Printer not found: $name" }
  $pages = @($job.pages)
  if ($pages.Count -lt 1) { throw 'Nothing to print.' }
  if ($job.reverse) { [array]::Reverse($pages) }
  if ($pages.Count -gt 500) { throw 'At most 500 pages in one job.' }
  $images = New-Object System.Collections.ArrayList
  foreach ($b64 in $pages) {
    $bytes = [Convert]::FromBase64String([string]$b64)
    $isPng = ($bytes.Length -ge 8) -and ($bytes[0] -eq 0x89) -and ($bytes[1] -eq 0x50) -and ($bytes[2] -eq 0x4E) -and ($bytes[3] -eq 0x47)
    $isJpg = ($bytes.Length -ge 3) -and ($bytes[0] -eq 0xFF) -and ($bytes[1] -eq 0xD8)
    if (-not ($isPng -or $isJpg)) { throw 'Pages must be PNG or JPEG pictures.' }
    $ms = New-Object System.IO.MemoryStream(,$bytes)
    [void]$images.Add([System.Drawing.Image]::FromStream($ms))
  }
  $doc = New-Object System.Drawing.Printing.PrintDocument
  $doc.PrinterSettings = $ps
  $doc.DocumentName = 'VLEBook ' + [string]$job.jobId
  $copies = [math]::Max(1, [math]::Min([int]$job.copies, [math]::Max(1, $ps.MaximumCopies)))
  $ps.Copies = [int16]$copies
  $ps.Collate = [bool]$job.collate
  if ($job.duplex -eq 'long' -and $ps.CanDuplex) { $ps.Duplex = [System.Drawing.Printing.Duplex]::Vertical }
  elseif ($job.duplex -eq 'short' -and $ps.CanDuplex) { $ps.Duplex = [System.Drawing.Printing.Duplex]::Horizontal }
  elseif ($job.duplex -eq 'off' -or -not $job.duplex) { if ($ps.CanDuplex) { $ps.Duplex = [System.Drawing.Printing.Duplex]::Simplex } }
  $pg = $doc.DefaultPageSettings
  if ($ps.SupportsColor) { $pg.Color = -not [bool]$job.monochrome }
  $pg.Landscape = [bool]$job.landscape
  $wMm = [double]$job.widthMm; $hMm = [double]$job.heightMm
  if ($job.paperName) {
    $found = $null
    foreach ($p in $ps.PaperSizes) { if ($p.PaperName -eq [string]$job.paperName) { $found = $p } }
    if ($found) { $pg.PaperSize = $found }
  } elseif ($wMm -gt 0 -and $hMm -gt 0) {
    $pw = [int][math]::Round([math]::Min($wMm, $hMm) / 0.254); $ph = [int][math]::Round([math]::Max($wMm, $hMm) / 0.254)
    $found = $null
    foreach ($p in $ps.PaperSizes) { if ([math]::Abs([math]::Min($p.Width, $p.Height) - $pw) -le 4 -and [math]::Abs([math]::Max($p.Width, $p.Height) - $ph) -le 4) { $found = $p; break } }
    if ($found) { $pg.PaperSize = $found } else { $pg.PaperSize = New-Object System.Drawing.Printing.PaperSize('VLEBook custom', $pw, $ph) }
  }
  if ($job.source) { foreach ($s in $ps.PaperSources) { if ($s.SourceName -eq [string]$job.source) { $pg.PaperSource = $s } } }
  if ($job.resolution) { foreach ($r in $ps.PrinterResolutions) { if ($r.X -eq [int]$job.resolution -and $r.Kind -eq 'Custom') { $pg.PrinterResolution = $r } } }
  $pg.Margins = New-Object System.Drawing.Printing.Margins(0, 0, 0, 0)
  $script:pi = 0
  $offX = [double]$job.offsetXmm; $offY = [double]$job.offsetYmm
  $exact = $job.scale -eq 'actual' -or -not $job.scale
  $pct = if ($job.scale -eq 'custom' -and [double]$job.scalePct -gt 0) { [double]$job.scalePct / 100 } else { 0 }
  $marg = [math]::Max(0, [double]$job.marginMm)
  $doc.add_PrintPage({
    param($s, $e)
    $img = $images[$script:pi]
    $g = $e.Graphics
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.PageUnit = [System.Drawing.GraphicsUnit]::Millimeter
    # The drawing origin is the printable-area corner: move back by the hard margin so (0,0) is the paper edge.
    $hx = $e.PageSettings.HardMarginX * 0.254; $hy = $e.PageSettings.HardMarginY * 0.254
    $pw = $e.PageBounds.Width * 0.254; $ph = $e.PageBounds.Height * 0.254
    if ($exact -and $wMm -gt 0 -and $hMm -gt 0) {
      $dw = $wMm; $dh = $hMm
      if ($e.PageSettings.Landscape -ne ($wMm -gt $hMm) -and [math]::Abs($pw - $hMm) -lt [math]::Abs($pw - $wMm)) { $dw = $hMm; $dh = $wMm }
      $g.DrawImage($img, [single](0 - $hx + $offX), [single](0 - $hy + $offY), [single]$dw, [single]$dh)
    } elseif ($pct -gt 0 -and $wMm -gt 0) {
      $dw = $wMm * $pct; $dh = $hMm * $pct
      $g.DrawImage($img, [single](($pw - $dw) / 2 - $hx + $offX), [single](($ph - $dh) / 2 - $hy + $offY), [single]$dw, [single]$dh)
    } else {
      $k = [math]::Min(($pw - 2 * $marg) / $img.Width, ($ph - 2 * $marg) / $img.Height)
      $dw = $img.Width * $k; $dh = $img.Height * $k
      $g.DrawImage($img, [single](($pw - $dw) / 2 - $hx + $offX), [single](($ph - $dh) / 2 - $hy + $offY), [single]$dw, [single]$dh)
    }
    $script:pi++
    $e.HasMorePages = $script:pi -lt $images.Count
  })
  try { $doc.Print() } finally { foreach ($i in $images) { $i.Dispose() }; $doc.Dispose() }
  return [ordered]@{ jobId = $job.jobId; status = 'SUBMITTED'; printer = $name; pages = $images.Count; copies = $copies; duplexApplied = [string]$ps.Duplex; at = (Get-Date).ToString('o'); note = 'Windows accepted the job for the printer. This does not prove the page or card came out.' }
}

function Get-PrinterState($name) {
  $w = $null
  try { $w = Get-CimInstance Win32_Printer -Filter ("Name='" + $name.Replace("'", "''").Replace('\', '\\') + "'") } catch {}
  if (-not $w) { throw "Printer not found: $name" }
  $err = @{ 0 = 'Unknown'; 1 = 'Other'; 2 = 'No error'; 3 = 'Low paper'; 4 = 'No paper'; 5 = 'Low toner / ribbon'; 6 = 'No toner / ribbon'; 7 = 'Door open'; 8 = 'Jammed'; 9 = 'Offline'; 10 = 'Service requested'; 11 = 'Output bin full' }
  $q = @(); try { $q = @(Get-CimInstance Win32_PrintJob | Where-Object { $_.Name -like ($name + ',*') }) } catch {}
  return [ordered]@{ name = $name; workOffline = [bool]$w.WorkOffline; detectedError = $err[[int]$w.DetectedErrorState]; printerStatus = [int]$w.PrinterStatus; jobsInQueue = $q.Count; note = 'As reported by Windows and the driver. Many card printers report only Ready / Offline here; ribbon and card levels are shown in the maker''s own status program.' }
}

function Get-JobState($id) {
  $j = $Jobs[$id]
  if (-not $j) { return [ordered]@{ jobId = $id; status = 'UNKNOWN' } }
  $q = $null
  try { $q = Get-CimInstance Win32_PrintJob | Where-Object { $_.Document -eq ('VLEBook ' + $id) } | Select-Object -First 1 } catch {}
  $state = if ($q) { if ([string]$q.JobStatus -match 'Error') { 'FAILED' } elseif ([string]$q.JobStatus -match 'Printing') { 'PRINTING' } else { 'QUEUED' } } else { 'LEFT_QUEUE' }
  return [ordered]@{ jobId = $id; status = $state; printer = $j.printer; submittedAt = $j.at; detail = if ($q) { [string]$q.JobStatus } else { 'No longer in the Windows print queue (finished, cancelled or removed). Check the printer.' } }
}

# ------------------------------------------------------------------ tiny HTTP server (127.0.0.1 only)

function Send($stream, [int]$code, $obj, $origin) {
  $json = if ($obj -is [string]) { $obj } else { $obj | ConvertTo-Json -Depth 8 -Compress }
  $body = [Text.Encoding]::UTF8.GetBytes($json)
  $reason = @{ 200 = 'OK'; 204 = 'No Content'; 400 = 'Bad Request'; 401 = 'Unauthorized'; 403 = 'Forbidden'; 404 = 'Not Found'; 413 = 'Payload Too Large'; 500 = 'Error' }[$code]
  $h = "HTTP/1.1 $code $reason`r`nContent-Type: application/json; charset=utf-8`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n"
  if ($origin) { $h += "Access-Control-Allow-Origin: $origin`r`nVary: Origin`r`nAccess-Control-Allow-Headers: Content-Type, X-Bridge-Token`r`nAccess-Control-Allow-Methods: GET, POST, OPTIONS`r`nAccess-Control-Allow-Private-Network: true`r`nAccess-Control-Max-Age: 600`r`n" }
  $hb = [Text.Encoding]::ASCII.GetBytes($h + "`r`n")
  $stream.Write($hb, 0, $hb.Length)
  if ($code -ne 204) { $stream.Write($body, 0, $body.Length) }
  $stream.Flush()
}

function Read-Request($client) {
  $stream = $client.GetStream()
  $stream.ReadTimeout = 15000
  $buf = New-Object byte[] 65536
  $ms = New-Object System.IO.MemoryStream
  $headEnd = -1
  while ($headEnd -lt 0) {
    $n = $stream.Read($buf, 0, $buf.Length)
    if ($n -le 0) { return $null }
    $ms.Write($buf, 0, $n)
    $all = $ms.ToArray()
    for ($i = 3; $i -lt $all.Length; $i++) { if ($all[$i - 3] -eq 13 -and $all[$i - 2] -eq 10 -and $all[$i - 1] -eq 13 -and $all[$i] -eq 10) { $headEnd = $i + 1; break } }
    if ($ms.Length -gt 65536 -and $headEnd -lt 0) { return $null }
  }
  $all = $ms.ToArray()
  $head = [Text.Encoding]::ASCII.GetString($all, 0, $headEnd)
  $lines = $head -split "`r`n"
  $first = $lines[0] -split ' '
  $hdr = @{}
  foreach ($l in $lines[1..($lines.Length - 1)]) { $k = $l.IndexOf(':'); if ($k -gt 0) { $hdr[$l.Substring(0, $k).Trim().ToLower()] = $l.Substring($k + 1).Trim() } }
  $len = 0
  if ($hdr['content-length']) { $len = [int64]$hdr['content-length'] }
  if ($len -gt $MaxBody) { return @{ stream = $stream; tooBig = $true; headers = $hdr } }
  $body = New-Object System.IO.MemoryStream
  if ($all.Length -gt $headEnd) { $body.Write($all, $headEnd, $all.Length - $headEnd) }
  while ($body.Length -lt $len) { $n = $stream.Read($buf, 0, $buf.Length); if ($n -le 0) { break }; $body.Write($buf, 0, $n) }
  return @{ stream = $stream; method = $first[0]; path = ($first[1] -split '\?')[0]; headers = $hdr; body = [Text.Encoding]::UTF8.GetString($body.ToArray()) }
}

# ------------------------------------------------------------------ install / uninstall (current user only, no admin rights)

$InstallDir = Join-Path $env:LOCALAPPDATA 'VLEBook Print Bridge'
function Get-Shortcuts {
  $startup = [Environment]::GetFolderPath('Startup')
  $programs = [Environment]::GetFolderPath('Programs')
  return @((Join-Path $startup 'VLEBook Print Bridge.lnk'), (Join-Path $programs 'VLEBook Print Bridge.lnk'))
}
function New-BridgeShortcut($path) {
  $sh = New-Object -ComObject WScript.Shell
  $lnk = $sh.CreateShortcut($path)
  $lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
  $lnk.Arguments = '"' + (Join-Path $InstallDir 'VLEBook Print Bridge.vbs') + '"'
  $lnk.WorkingDirectory = $InstallDir
  $lnk.Description = 'VLEBook Print Bridge - lets VLEBook print to the printers of this computer'
  $lnk.IconLocation = (Join-Path $env:WINDIR 'System32\imageres.dll') + ',46'
  $lnk.Save()
}
function Set-AutoStart([bool]$on) {
  $p = (Get-Shortcuts)[0]
  if ($on) { New-BridgeShortcut $p } elseif (Test-Path $p) { Remove-Item -Force $p }
}
function Stop-OtherBridges {
  try {
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -like '*VLEBook-Print-Bridge.ps1*' -and $_.ProcessId -ne $PID } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
  } catch {}
}
if ($Install) {
  # Called by "Install VLEBook Print Bridge.cmd" after the files were copied to $InstallDir
  Stop-OtherBridges
  foreach ($p in (Get-Shortcuts)) { New-BridgeShortcut $p }
  Log "Installed version $Version in $InstallDir (starts with Windows; Start menu: VLEBook Print Bridge)."
  exit 0
}
if ($Uninstall) {
  Stop-OtherBridges
  foreach ($p in (Get-Shortcuts)) { if (Test-Path $p) { Remove-Item -Force $p } }
  Log 'Uninstalled: shortcuts removed. Settings remain in %APPDATA%\VLEBookPrintBridge until you delete that folder.'
  exit 0
}

# ------------------------------------------------------------------ notification-area (tray) icon

$Tray = $null
$Quit = $false
function New-TrayIcon {
  $bmp = New-Object System.Drawing.Bitmap 32, 32
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.Clear([System.Drawing.Color]::Transparent)
  $g.FillEllipse((New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(8, 126, 139))), 0, 0, 31, 31)
  $font = New-Object System.Drawing.Font 'Segoe UI', 15, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
  $fmt = New-Object System.Drawing.StringFormat
  $fmt.Alignment = [System.Drawing.StringAlignment]::Center
  $fmt.LineAlignment = [System.Drawing.StringAlignment]::Center
  $g.DrawString('P', $font, [System.Drawing.Brushes]::White, (New-Object System.Drawing.RectangleF 0, 0, 32, 32), $fmt)
  $g.Dispose()
  return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}
function Update-TrayText {
  if (-not $Tray) { return }
  $n = 0; try { $n = ([System.Drawing.Printing.PrinterSettings]::InstalledPrinters).Count } catch {}
  $t = "VLEBook Print Bridge $Version - $n printers - " + $(if ($Tokens.Count) { 'connected' } else { 'waiting for VLEBook' })
  $Tray.Text = $t.Substring(0, [Math]::Min(63, $t.Length))
  if ($script:MenuState) { $script:MenuState.Text = $t }
}
function Show-Balloon($title, $text) {
  if ($Tray) { try { $Tray.ShowBalloonTip(5000, $title, $text, [System.Windows.Forms.ToolTipIcon]::Info) } catch {} }
}
function Start-Tray {
  Add-Type -AssemblyName System.Windows.Forms
  [System.Windows.Forms.Application]::EnableVisualStyles()
  $script:Tray = New-Object System.Windows.Forms.NotifyIcon
  $Tray.Icon = New-TrayIcon
  $menu = New-Object System.Windows.Forms.ContextMenuStrip
  $script:MenuState = $menu.Items.Add('VLEBook Print Bridge ' + $Version)
  $script:MenuState.Enabled = $false
  [void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
  $open = $menu.Items.Add('Open VLEBook')
  $open.add_Click({ Start-Process $AppUrl })
  $logItem = $menu.Items.Add('Show log')
  $logItem.add_Click({ if (Test-Path $LogFile) { Start-Process notepad.exe $LogFile } })
  $auto = New-Object System.Windows.Forms.ToolStripMenuItem 'Start with Windows'
  $auto.Checked = Test-Path ((Get-Shortcuts)[0])
  $auto.CheckOnClick = $true
  $auto.add_Click({ try { Set-AutoStart $this.Checked; Log ('Start with Windows: ' + $this.Checked) } catch { Log ('Start with Windows could not be changed: ' + $_.Exception.Message) } })
  [void]$menu.Items.Add($auto)
  $disc = $menu.Items.Add('Disconnect all browsers')
  $disc.add_Click({ $Tokens.Clear(); SaveTokens; Update-TrayText; Log 'All browsers disconnected from the tray menu.' })
  [void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
  $quit = $menu.Items.Add('Quit Print Bridge')
  $quit.add_Click({ $script:Quit = $true })
  $Tray.ContextMenuStrip = $menu
  $Tray.add_DoubleClick({ Start-Process $AppUrl })
  $Tray.Visible = $true
  Update-TrayText
}

$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
try { $listener.Start() } catch {
  # Port in use: another Print Bridge is already running (for example started with Windows). Nothing to do.
  Log "Port $Port is already in use - another Print Bridge is running. This copy exits."
  if ($Console) { Write-Host "Port $Port is already in use. Is the Bridge already running?"; Read-Host 'Press Enter to close' }
  exit 0
}
Log "VLEBook Print Bridge $Version started on 127.0.0.1:$Port. Paired browsers: $($Tokens.Count). Printers found: $(([System.Drawing.Printing.PrinterSettings]::InstalledPrinters).Count)"
if ($Console) {
  $Host.UI.RawUI.WindowTitle = "VLEBook Print Bridge $Version - keep open while printing"
  Write-Host "  VLEBook Print Bridge $Version is running (console mode). Close this window to stop."
} else {
  Start-Tray
  if (-not $Tokens.Count) { Show-Balloon 'VLEBook Print Bridge is running' 'Open VLEBook - it connects automatically. The icon stays here in the notification area.' }
}

while (-not $Quit) {
  if (-not $listener.Pending()) {
    if ($Tray) { [System.Windows.Forms.Application]::DoEvents() }
    Start-Sleep -Milliseconds 40
    continue
  }
  $client = $listener.AcceptTcpClient()
  try {
    $req = Read-Request $client
    if (-not $req) { $client.Close(); continue }
    $origin = [string]$req.headers['origin']
    $okOrigin = $origin -and ($AllowedOrigins -contains $origin)
    if ($req.tooBig) { Send $req.stream 413 @{ error = 'TOO_BIG'; message = 'The print job is too large.' } ($(if ($okOrigin) { $origin } else { $null })); $client.Close(); continue }
    if (-not $okOrigin) { Send $req.stream 403 @{ error = 'ORIGIN'; message = 'Only VLEBook may use the Print Bridge.' } $null; $client.Close(); continue }
    if ($req.method -eq 'OPTIONS') { Send $req.stream 204 '' $origin; $client.Close(); continue }
    $path = $req.path
    $data = $null
    if ($req.body) { try { $data = ParseJson $req.body } catch { Send $req.stream 400 @{ error = 'BAD_JSON'; message = 'Bad request.' } $origin; $client.Close(); continue } }
    if ($path -eq '/v1/health') { Send $req.stream 200 @{ ok = $true; name = 'VLEBook Print Bridge'; version = $Version; paired = [bool]($Tokens.ContainsKey([string]$req.headers['x-bridge-token'])); autoPair = [bool]($AutoPairOrigins -contains $origin); os = [Environment]::OSVersion.VersionString } $origin; $client.Close(); continue }
    if ($path -eq '/v1/pair/auto') {
      # The VLEBook web address is trusted on this computer: connect without a code (only that address; browsers set Origin).
      if ($AutoPairOrigins -notcontains $origin) { Send $req.stream 403 @{ error = 'PAIR_CODE_REQUIRED'; message = 'This address must pair with a code.' } $origin; $client.Close(); continue }
      $tok = NewToken; $Tokens[$tok] = @{ origin = $origin; at = (Get-Date).ToString('o'); label = [string]$data.label; auto = $true }; SaveTokens
      Log "VLEBook connected automatically ($origin)."
      Update-TrayText
      Show-Balloon 'VLEBook connected' 'VLEBook can now print to the printers of this computer.'
      Send $req.stream 200 @{ ok = $true; token = $tok; auto = $true } $origin; $client.Close(); continue
    }
    if ($path -eq '/v1/pair/start') {
      $script:PairCode = NewCode; $script:PairUntil = (Get-Date).AddMinutes(3)
      Log "Pairing code requested by $origin (shown in the notification)."
      Show-Balloon 'VLEBook Print Bridge pairing code' ("Type this code in VLEBook: " + $PairCode + " (valid 3 minutes)")
      if ($Console) { Write-Host ''; Write-Host "  >>> Pairing code for VLEBook:  $PairCode   (valid 3 minutes)" -ForegroundColor Yellow; Write-Host '' }
      Send $req.stream 200 @{ ok = $true; message = 'Type the 6-digit code shown in the Print Bridge notification (or its window in console mode).' } $origin; $client.Close(); continue
    }
    if ($path -eq '/v1/pair/finish') {
      if (-not $PairCode -or (Get-Date) -gt $PairUntil -or [string]$data.code -ne $PairCode) { $script:PairCode = $null; Send $req.stream 401 @{ error = 'PAIR'; message = 'Wrong or expired code. Start pairing again.' } $origin; $client.Close(); continue }
      $tok = NewToken; $Tokens[$tok] = @{ origin = $origin; at = (Get-Date).ToString('o'); label = [string]$data.label }; SaveTokens; $script:PairCode = $null
      Log "Browser paired ($origin)."
      Update-TrayText
      Send $req.stream 200 @{ ok = $true; token = $tok } $origin; $client.Close(); continue
    }
    $tok = [string]$req.headers['x-bridge-token']
    if (-not $tok -or -not $Tokens.ContainsKey($tok)) { Send $req.stream 401 @{ error = 'NOT_PAIRED'; message = 'Pair this browser with the Print Bridge first.' } $origin; $client.Close(); continue }
    switch -Regex ($path) {
      '^/v1/printers$' { Send $req.stream 200 @{ ok = $true; printers = (Get-PrinterList) } $origin }
      '^/v1/capabilities$' { try { Send $req.stream 200 @{ ok = $true; caps = (Get-PrinterCaps ([string]$data.printer)) } $origin } catch { Send $req.stream 404 @{ error = 'PRINTER'; message = $_.Exception.Message } $origin } }
      '^/v1/print$' {
        $id = [string]$data.jobId
        if ($id -notmatch '^[A-Za-z0-9_-]{6,60}$') { Send $req.stream 400 @{ error = 'JOB_ID'; message = 'Bad job number.' } $origin; break }
        if ($Jobs.ContainsKey($id)) { Send $req.stream 200 $Jobs[$id].result $origin; break }   # same job sent twice: not printed again
        try { $r = Invoke-Print $data; $Jobs[$id] = @{ printer = $data.printer; at = $r.at; result = $r }; Log "Job $id sent to '$($data.printer)' ($($r.pages) page(s) x $($r.copies))."; Send $req.stream 200 $r $origin }
        catch { Log "Job $id failed: $($_.Exception.Message)"; Send $req.stream 500 @{ error = 'PRINT_FAILED'; message = $_.Exception.Message; jobId = $id } $origin }
      }
      '^/v1/job$' { Send $req.stream 200 (Get-JobState ([string]$data.jobId)) $origin }
      '^/v1/status$' { try { Send $req.stream 200 @{ ok = $true; state = (Get-PrinterState ([string]$data.printer)) } $origin } catch { Send $req.stream 404 @{ error = 'PRINTER'; message = $_.Exception.Message } $origin } }
      '^/v1/preferences$' {
        # Opens the printer maker's own "Printing preferences" window on this computer (ribbon, K panel, lamination, card feed ...)
        $pn = [string]$data.printer
        if (-not ([System.Drawing.Printing.PrinterSettings]::InstalledPrinters -contains $pn)) { Send $req.stream 404 @{ error = 'PRINTER'; message = 'Printer not found.' } $origin; break }
        Start-Process -FilePath 'rundll32.exe' -ArgumentList @('printui.dll,PrintUIEntry', '/e', '/n', $pn)
        Log "Opened printing preferences for '$pn'."
        Send $req.stream 200 @{ ok = $true } $origin
      }
      '^/v1/cancel$' {
        $id = [string]$data.jobId; $n = 0
        try { Get-CimInstance Win32_PrintJob | Where-Object { $_.Document -eq ('VLEBook ' + $id) } | ForEach-Object { Remove-CimInstance -InputObject $_; $n++ } } catch {}
        Send $req.stream 200 @{ ok = $true; cancelled = $n } $origin
      }
      '^/v1/unpair$' { $Tokens.Remove($tok); SaveTokens; Send $req.stream 200 @{ ok = $true } $origin }
      default { Send $req.stream 404 @{ error = 'NOT_FOUND'; message = 'Unknown request.' } $origin }
    }
  } catch {
    try { Log ("Request error: " + $_.Exception.Message) } catch {}
  } finally { try { $client.Close() } catch {} }
}
try { $listener.Stop() } catch {}
if ($Tray) { $Tray.Visible = $false; $Tray.Dispose() }
Log 'Print Bridge stopped.'
