VLEBook Print Bridge 1.2.0 (for VLEBook 3.4)

INSTALL (once per Windows user, no administrator rights):
1. Unzip this folder.
2. Double-click "Install VLEBook Print Bridge.cmd".
   If Windows shows "Windows protected your PC", click More info -> Run anyway
   (all files are plain text you can read in Notepad).
3. That is all. The Bridge now runs in the background with an icon in the notification
   area (click ^ next to the clock), starts by itself with Windows, and VLEBook connects
   to it automatically - no code to type. Open VLEBook -> PDF & Image Studio -> Print & printers.
   If Chrome or Edge asks to allow access to devices on your local network, choose Allow.

TRAY ICON (right-click): status, Open VLEBook, Show log, Start with Windows, Disconnect all browsers, Quit.

SAFETY: works only on this computer (127.0.0.1). Connects automatically only to the VLEBook web address
(https://tools.complypro.co.in); any other address must pair with a 6-digit code shown in a notification.
It never runs commands sent to it, never reads or writes your files, and keeps no copy of what is printed.
The log (Show log) contains times, job numbers and printer names only.

UNINSTALL: run "Uninstall VLEBook Print Bridge.cmd"
in %LOCALAPPDATA%\VLEBook Print Bridge, then delete that folder and %APPDATA%\VLEBookPrintBridge.

TROUBLESHOOTING: "Start VLEBook Print Bridge (window).cmd" runs it in a visible window and shows messages.

Printer features shown in VLEBook are exactly what the Windows driver reports.
Printing on your PVC / card printer is to be checked by you after going live.
