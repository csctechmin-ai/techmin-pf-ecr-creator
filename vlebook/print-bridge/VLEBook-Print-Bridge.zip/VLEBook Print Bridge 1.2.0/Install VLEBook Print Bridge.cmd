@echo off
rem VLEBook Print Bridge - installer for this Windows user (no administrator rights needed).
rem Copies the Bridge to your user folder, adds it to Windows start-up and the Start menu, and starts it in the background.
setlocal
set "DEST=%LOCALAPPDATA%\VLEBook Print Bridge"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0VLEBook-Print-Bridge.ps1" "%DEST%\" >nul
copy /Y "%~dp0VLEBook Print Bridge.vbs" "%DEST%\" >nul
copy /Y "%~dp0Uninstall VLEBook Print Bridge.cmd" "%DEST%\" >nul
copy /Y "%~dp0Start VLEBook Print Bridge (window).cmd" "%DEST%\" >nul
copy /Y "%~dp0README.txt" "%DEST%\" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DEST%\VLEBook-Print-Bridge.ps1" -Install
if errorlevel 1 (
  echo.
  echo The Print Bridge could not be installed. See README.txt.
  pause
  exit /b 1
)
start "" wscript.exe "%DEST%\VLEBook Print Bridge.vbs"
echo.
echo  VLEBook Print Bridge is installed and running.
echo  Its icon is in the notification area (click ^^ next to the clock).
echo  It starts with Windows and connects to VLEBook by itself.
echo.
echo  This window closes in 8 seconds.
timeout /t 8 >nul
