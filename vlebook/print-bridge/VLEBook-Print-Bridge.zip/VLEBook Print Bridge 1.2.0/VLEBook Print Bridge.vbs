' VLEBook Print Bridge - starts the Bridge hidden (icon in the notification area, no window).
Option Explicit
Dim sh, fso, dir, ps, cmd, build
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
ps = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\VLEBook-Print-Bridge.ps1"""
build = 0
On Error Resume Next
build = CLng(sh.RegRead("HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\CurrentBuildNumber"))
On Error GoTo 0
' Windows 10 1903 (build 18362) and later: run in a headless console so no window can appear, even when Windows Terminal is the default terminal
If build >= 18362 And fso.FileExists(sh.ExpandEnvironmentStrings("%WINDIR%") & "\System32\conhost.exe") Then
  cmd = "conhost.exe --headless " & ps
Else
  cmd = ps
End If
sh.Run cmd, 0, False
