@echo off
rem VLEBook Print Bridge - uninstaller: stops the Bridge and removes its start-up and Start menu shortcuts.
set "DEST=%LOCALAPPDATA%\VLEBook Print Bridge"
if exist "%DEST%\VLEBook-Print-Bridge.ps1" (powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%DEST%\VLEBook-Print-Bridge.ps1" -Uninstall) else (powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0VLEBook-Print-Bridge.ps1" -Uninstall)
echo.
echo  VLEBook Print Bridge was stopped and removed from start-up and the Start menu.
echo  To remove its files too, delete these folders:
echo    %DEST%
echo    %APPDATA%\VLEBookPrintBridge
echo.
pause
